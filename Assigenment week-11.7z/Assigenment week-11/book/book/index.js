const express = require('express')
const app = express()
const port = 3000

var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/bookr');
var MongoClient = require('mongodb').MongoClient
var ObjectID = require('mongodb').ObjectID

app.use(express.json())
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'))
app.set('view engine', 'pug')
app.set('views', __dirname + '/views');

var bookSchema = new mongoose.Schema({
  author: { type: String, required: true },
  title: { type: String, required: true },
  content: { type: String, required: true },
  No_of_Pages: { type: String, required: true }
});
var book = mongoose.model('book', bookSchema);

var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function() {

  app.get('/', (req, res) => {
    book.find({}, function(err, books) {
      if (err) {
        console.log(err)
        res.render('error', {})
      } else {
        res.render('index', { books: books })
      }
    });
  });

  app.get('/books/new', (req, res) => {
    res.render('book-form', { title: "New book", book: {} })
  });

  app.get('/books/:id/update', (req, res) => {
    let id = ObjectID.createFromHexString(req.params.id)

    book.findById(id, function(err, book) {
      if (err) {
        console.log(err)
        res.render('error', {})
      } else {
        if (book === null) {
          res.render('error', { message: "Not found" })
        } else {
          res.render('book-form', { title: "Update book", book: book })
        }
      }
    });
  });

  app.post('/books/new', function(req, res, next) {
    let newbook = new book(req.body);
    newbook.save(function(err, savedbook){
      if (err) {
        console.log(err)
        res.render('book-form', { book: newbook, error: err })
      } else {
        res.redirect('/books/' + savedbook.id);
      }
    });
  });

  app.get('/books/:id', (req, res) => {
    let id = ObjectID.createFromHexString(req.params.id)

    book.findById(id, function(err, book) {
      if (err) {
        console.log(err)
        res.render('error', {})
      } else {
        if (book === null) {
          res.render('error', { message: "Not found" })
        } else {
          res.render('book-detail', { book: book})
        }
      }
    });
  });

  app.post('/books/:id/update', function(req, res, next) {
    let id = ObjectID.createFromHexString(req.params.id)

    book.updateOne({"_id": id}, { $set: req.body }, function(err, details) {
      if (err) {
        console.log(err)
        res.render('error', {})
      } else {
        res.redirect('/books/' + id);
      }
    });
  });

  app.post('/books/:id/delete', function (req, res) {
    let id = ObjectID.createFromHexString(req.params.id)
    book.deleteOne({_id: id}, function(err, product) {
      res.redirect("/");
    });
  });

  app.post('/api/books', (req, res) => {
    console.log(req.body)
    let newbook = new book(req.body)

    newbook.save(function (err, savedbook) {
      if (err) {
        console.log(err)
        res.status(500).send("There was an internal error")
      } else {
        res.send(savedbook)
      }
    });
  });

  app.get('/api/books', (req, res) => {
    book.find({}, function(err, books) {
      if (err) {
        console.log(err)
        res.status(500).send("Internal server error")
      } else {
        res.send(books)
      }
    });
  });

  app.get('/api/books/:id', (req, res) => {
    let id = ObjectID.createFromHexString(req.params.id)

    book.findById(id, function(err, book) {
      if (err) {
        console.log(err)
        res.status(500).send("Internal server error")
      } else {
        if (book === null) {
          res.status(404).send("Not found")
        } else {
          res.send(book)
        }
      }
    });
  });

  app.put('/api/books/:id', (req, res) => {
    let id = ObjectID.createFromHexString(req.params.id)

    book.updateOne({"_id": id}, { $set: req.body }, function(err, details) {
      if (err) {
        console.log(err)
        res.status(500).send("Internal server error")
      } else {
        res.status(204).send()
      }
    });
  });

  app.delete('/api/books/:id', (req, res) => {
    let id = ObjectID.createFromHexString(req.params.id)

    book.deleteOne({"_id": id}, function(err) {
      if (err) {
        console.log(err)
        res.status(500).send("Internal server error")
      } else {
        res.status(204).send()
      }
    });
  });
});

app.listen(port, () => console.log(`Example app listening on port ${port}!`))
